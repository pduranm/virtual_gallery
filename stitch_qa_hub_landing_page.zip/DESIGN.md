# Design System Specification: Immersive Flow

## 1. Overview & Creative North Star
**Creative North Star: The Precision Kineticist**

This design system is a rejection of the static, "boxy" web. For a boutique technical QA agency, we must balance the cold, absolute precision of code with the fluid, vanguard nature of modern digital craftsmanship. We move away from traditional vertical scrolling patterns toward a **Horizontal Narrative**, where the UI feels like a continuous stream of data and motion.

The aesthetic is "Industrial Elegance"—sharp, uncompromising edges for functional elements (buttons, inputs) contrasted against massive, organic glass "blobs" that drift behind the content. By layering high-contrast typography over deep, tonal indigo voids, we create an environment that feels both high-security and high-innovation.

---

## 2. Colors & Surface Philosophy

### The Palette
The core of the system is built on deep, light-absorbing foundations and high-frequency accents.

*   **Foundation:** Deep indigo-charcoals (`surface`: #10141a) provide the "void" in which data lives.
*   **The Pulse:** `primary` (#4ADE80) is our "Electric Emerald." It represents the "Go" state, the successful test, the clean code.
*   **The Logic:** `secondary` (#e0b6ff) "Cyber Purple" is used for secondary actions and technical categorization.
*   **The Tech:** `tertiary` (#ffd9c1) provides a warm, human contrast to the cold digital tones, used for high-level technical insights.

### The "No-Line" Rule
**Borders are forbidden for structural sectioning.** We do not use 1px lines to separate headers from bodies or cards from grids. Boundaries must be defined by:
1.  **Tonal Shifts:** Placing a `surface-container-high` card on a `surface-container-lowest` background.
2.  **Negative Space:** Using aggressive margins to define "zones" of information.
3.  **Edge Transitions:** Soft, horizontal gradients that fade content into the next section.

### Glass & Gradient Execution
To achieve the "Immersive Flow" style, use **Backdrop Blurs** (minimum 24px) combined with `surface-variant` at 40% opacity. This creates a "Frosted Tech" look. Hero sections should feature a slow-moving radial gradient transitioning from `primary` to `primary-container` at 5% opacity to give the "void" a sense of atmospheric depth.

---

## 3. Typography: The Tension of Type
We utilize a high-contrast pairing: the aggressive, wide-set **Space Grotesk** for brand authority and a precise, functional **Inter** for technical density.

*   **Display (Space Grotesk):** Set with `letter-spacing: -0.02em` and `text-transform: uppercase`. These should feel like architectural statements.
*   **Technical Detail (Inter Mono/Precision):** Used for code snippets, QA logs, and labels. It conveys the "Boutique Agency" feel—meticulous and error-free.
*   **The Scale:**
    *   **Display LG (3.5rem):** Reserved for hero hooks and major section transitions.
    *   **Headline LG (2rem):** Used for mid-section narrative shifts.
    *   **Label MD (0.75rem):** All-caps with `letter-spacing: 0.1em` for metadata and technical tags.

---

## 4. Elevation & Depth: Tonal Layering

Traditional drop shadows are replaced by **Tonal Stacking**.

*   **The Layering Principle:** 
    *   **Background:** `surface` (#10141a)
    *   **Section Trays:** `surface-container-low` (#181c22)
    *   **Active Cards:** `surface-container-high` (#262a31)
    *   **Interactive Elements:** `surface-bright` (#353940)
*   **The Ghost Border:** If a boundary is required for accessibility in forms, use `outline-variant` at 15% opacity. It should be barely perceptible, a "suggestion" of a boundary rather than a hard wall.
*   **Fluid Depth:** Use large, blurred organic shapes (using `primary` and `secondary` at 10% opacity) floating between the `surface` and `surface-container` layers. These shapes should move slightly on mouse-over (Parallax) to reinforce the kinetic nature of the system.

---

## 5. Components

### Buttons: The Kinetic Trigger
*   **Primary:** Sharp 0px corners. Background: `primary` (#4ADE80). Text: `on-primary` (#003919). 
    *   *Interaction:* On hover, the button should expand horizontally by 4px, and the color should shift to `primary-container`.
*   **Tertiary (Ghost):** No background. `outline` color for text. On hover, a 10% `primary` background "bleeds" in from the left.

### Cards: The Data Vessel
*   **Styling:** 0px border radius. Background: `surface-container`. 
*   **Rule:** No dividers. Use `label-sm` headers in `primary` color to separate internal card data.
*   **Motion:** Cards should enter the frame with a staggered horizontal slide (Ease-out-expo).

### Technical Chips
*   **Design:** Small, rectangular, 0px radius. Use `secondary-container` for the fill and `on-secondary-container` for text.
*   **Context:** Used for "Test Passed," "Bug Found," or "Latency" metrics.

### Inputs: The Command Line
*   **Design:** Minimalist. A single bottom-weighted line using `outline-variant`. 
*   **Focus State:** The line transforms into a `primary` glow. The label should use a monospace font to mimic a terminal input.

### Horizontal Progress Rail
*   **Context:** Since the layout emphasizes horizontal progression, a persistent "Rail" at the bottom of the screen (using `surface-container-highest`) shows the user's position in the narrative.

---

## 6. Do’s and Don’ts

### Do
*   **DO** use extreme horizontal padding (8vw+) to create an editorial, cinematic feel.
*   **DO** mix font weights aggressively—pair a `display-lg` Bold with a `label-sm` Regular.
*   **DO** allow organic glass elements to partially obscure text to create a sense of three-dimensional depth.
*   **DO** use "Electric Emerald" sparingly for maximum impact; it is a laser, not a paint bucket.

### Don’t
*   **DON’T** use rounded corners (`0px` is the absolute rule). Roundedness destroys the technical "QA" precision of the brand.
*   **DON’T** use standard vertical "stacked cards" for main features. Look for ways to stagger them horizontally or overlap them.
*   **DON’T** use pure black (#000). Always use the indigo-charcoal `surface` to maintain the "Immersive Flow" atmosphere.
*   **DON’T** use 1px solid borders at 100% opacity. They "trap" the flow and break the immersion.